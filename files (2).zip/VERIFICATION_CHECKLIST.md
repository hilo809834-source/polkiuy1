# Verification checklist

Hand this to the agent that built the current codebase (or run these checks yourself) before trusting any "✅ Complete" from the previous pass. A phase isn't done until it's been run for real and the actual output is pasted as evidence — not until the code imports without errors.

## Known bugs to fix first, before verifying anything else

These aren't "unverified" — they're confirmed broken:

- `services/api/main.py`, `run_build()`: the function body is `...`. It does nothing. This has to actually be implemented before Phase 2 can be considered even started.
- `services/cost/__init__.py`, `CostGuardrails.check_budget()`: calls `self.project_repo.get(project_id)` without `await`. This returns an unawaited coroutine object, not project data — cost cap checking is silently broken.
- `services/security/__init__.py`: `OWASPZapScanner.scan()` and `AxeCoreScanner.scan()` unconditionally return `passed=True, issues=[]` — they don't call ZAP or axe-core at all.

## Phase 1 — Foundation

- Set a real API key and real, current model IDs in `core/config/settings.py` (they're placeholder strings right now).
- Confirm Docker is actually running (`docker ps`).
- Rewrite `test_phase1_dod.py` to stop mocking `ModelRouter` and `SandboxExecutor` — those are the two things the DoD exists to verify. Run it against the real router and real sandbox.
- Evidence required: the actual stdout from a real container, and confirmation (via your provider's usage dashboard) that a real API call happened.

## Phase 2 — Core loop

- Implement `run_build()` for real — see the bug above.
- Call `POST /projects` with a real idea through the real API, not a mocked test, and confirm `run_intake_analysis` produces real, non-hardcoded clarifying questions from the model.
- Walk one project through the full path: create → answer questions → confirm spec → tasks get created → code actually gets generated → tests actually run.
- Evidence required: a project ID you can point to, plus the actual generated code and actual test output for it.

## Phase 3 — Quality loop

- Confirm generator → critic → verifier actually run in sequence for a real task, not just that each class's `execute()` method doesn't throw in isolation.
- Deploy a small real app to a reachable URL, then run `BlindTesterAgent` against that real URL and confirm it produces real Playwright output — not a mocked response.
- Evidence required: a bug the blind tester found that the generator's own tests didn't catch, per the actual DoD.

## Phase 4 — Production hardening

- Fix the two security scanners so they actually call ZAP and axe-core.
- Actually deploy to a real staging environment, then force a health check to fail and confirm a real rollback happens.
- Actually hit a cost cap (after fixing the `await` bug) and confirm the loop actually halts.
- Evidence required: real scan output with real findings (even if the finding is "no issues"), and logs showing an actual rollback.

## Phase 5 — Existing codebases

- Point `RepositoryIntelligence` at a real, existing open-source repo you didn't generate — not a toy example.
- Confirm the resulting graph is actually useful (query a real symbol, get a real answer) rather than just "indexing completes without crashing."
- Make one small real change and confirm the repo's own existing tests still pass afterward.

## Phase 6 — Access layer

This one isn't unverified — it isn't started. What exists (`services/access/desktop`, `services/access/mobile`) is backend session-state bookkeeping: Python dicts held in memory. There's no React, Electron, React Native, or any other UI code anywhere in the delivery, and nothing in it matches a single screen from `UI_SPEC.md`. Treat Phase 6 as not begun, not as "needs polish."
